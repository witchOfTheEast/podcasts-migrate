#!/bin/bash
usage() {
    echo -e "Usage: ${basename} /DIRECTORY"
    echo -e "The /DIRECTORY is required and should be the top-level directory holding the sub-directories and misnamed files"
}
    
if [[ $# != 1 ]]; then
    usage
    exit 1
fi

if ! [[ -d "$1" ]]; then
    usage
    exit 1
else
    start_dir="$1"
fi
while true; do
    read -p "This program is going to move and rename files. Are you sure you want to proceed? [Y/N]" response
    case $response in
        [Yy]* ) 
            find "$start_dir" -maxdepth 1 -type d -print0 |
                while IFS= read -r -d $'\0' found_dir; do
                    if [[ "${#found_dir}" -gt 1 ]]; then
                        dir_name_only="$(echo "$found_dir" | sed 's/\.\///')";
                        mv -t "$dir_name_only/" ${dir_name_only}*mp3 > /dev/null 2>&1;
                        cd "$dir_name_only";
                        rename "$dir_name_only" '' *.mp3;
                        cd - > /dev/null;
                    fi
                done
                ;;
        [Nn]* ) 
            exit
            ;;
    esac
done
